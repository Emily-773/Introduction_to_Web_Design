< !DOCTYPE html >
    <html lang="en">
        <head>
            <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>UK TV Search Tool</title>
                    <link rel="stylesheet" href="styles.css">
                        <style>
                            body {
                                font - family: Arial, sans-serif;
                            background-color: #f5f5f5;
                            color: #333;
                            text-align: center;
        }
                            header {
                                background - color: #004466;
                            color: #ffffff;
                            padding: 1em;
        }
                            input, button {
                                font - size: 1.2em;
                            padding: 0.5em;
                            margin: 0.5em;
        }
                            input {
                                border: 2px solid #0077b6;
                            background-color: #ffffff;
                            color: #000;
        }
                            button {
                                background - color: #0077b6;
                            color: white;
                            border: none;
                            cursor: pointer;
        }
                            button:hover, button:focus {
                                background - color: #005f87;
                            outline: 2px solid #ffcc00;
        }
                            #results, #history, #favourites {
                                margin - top: 1em;
                            text-align: left;
                            padding: 1em;
        }
                            .visually-hidden {
                                position: absolute;
                            width: 1px;
                            height: 1px;
                            padding: 0;
                            margin: -1px;
                            overflow: hidden;
                            clip: rect(0, 0, 0, 0);
                            border: 0;
        }
                            .high-contrast {
                                background - color: #000;
                            color: #fff;
        }
                            .show-card {
                                border: 2px solid #0077b6;
                            padding: 1em;
                            margin: 1em;
                            background-color: #ffffff;
                            color: #000;
        }
                            .show-card img {
                                max - width: 100%;
                            height: auto;
        }
                        </style>
                    </head>
                    <body>
                        <header>
                            <h1>UK TV Search Tool</h1>
                            <button id="toggleContrast" aria-label="Toggle High Contrast Mode">High Contrast</button>
                        </header>
                        <main>
                            <label for="search" class="visually-hidden">Search for a UK TV Show</label>
                            <input type="text" id="search" placeholder="Search for a UK TV show..." aria-label="Search for a UK TV show">
                                <button id="searchBtn">Search</button>
                                <div id="results" role="region" aria-live="polite"></div>
                                <h2>Search History</h2>
                                <ul id="history"></ul>
                                <h2>Favourites</h2>
                                <ul id="favourites"></ul>
                        </main>
                        <script>
                            document.getElementById('toggleContrast').addEventListener('click', function() {
                                document.body.classList.toggle('high-contrast');
        });

                            const historyContainer = document.getElementById('history');
                            const favouritesContainer = document.getElementById('favourites');
                            let searchHistory = JSON.parse(localStorage.getItem('searchHistory')) || [];
                            let favourites = JSON.parse(localStorage.getItem('favourites')) || [];

                            function updateHistory() {
                                historyContainer.innerHTML = searchHistory.map(query => `<li>${query}</li>`).join('');
        }

                            function updateFavourites() {
                                favouritesContainer.innerHTML = favourites.map(show => `<li>${show}</li>`).join('');
        }

                            document.getElementById('searchBtn').addEventListener('click', function() {
            const query = document.getElementById('search').value.trim();
                            if (query) {
                                searchHistory.push(query);
                            localStorage.setItem('searchHistory', JSON.stringify(searchHistory));
                            updateHistory();

                            fetch(`https://api.tvmaze.com/search/shows?q=${query}`)
                    .then(response => response.json())
                    .then(data => {
                        const resultsContainer = document.getElementById('results');
                            resultsContainer.innerHTML = '';
                        data.forEach(item => {
                            if (item.show.network && item.show.network.country.code === "GB") {
                                const showCard = document.createElement('div');
                            showCard.classList.add('show-card');
                            showCard.innerHTML = `
                            <h2>${item.show.name}</h2>
                            <p>${item.show.summary || 'No description available.'}</p>
                            ${item.show.image ? `<img src="${item.show.image.medium}" alt="Poster of ${item.show.name}">` : ''}
                            <button onclick="addToFavourites('${item.show.name}')">Add to Favourites</button>
                                `;
                                resultsContainer.appendChild(showCard);
                            }
                        });
                        if (resultsContainer.innerHTML === '') {
                            resultsContainer.innerHTML = '<p>No UK TV shows found.</p>';
                        }
                    })
                    .catch(error => console.error('Error fetching data:', error));
            }
        });

        function addToFavourites(show) {
            if (!favourites.includes(show)) {
                favourites.push(show);
                localStorage.setItem('favourites', JSON.stringify(favourites));
                updateFavourites();
            }
        }

        updateHistory();
        updateFavourites();
    </script>
</body>
</html>

