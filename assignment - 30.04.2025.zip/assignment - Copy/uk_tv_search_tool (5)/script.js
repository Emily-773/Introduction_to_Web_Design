// YOUR EXISTING CODE...

// Display results with clickable cards
function displayResults(shows) {
    console.log("Displaying results...");
    results.innerHTML = '';
    if (shows.length === 0) {
        results.innerHTML = '<p>No UK shows found.</p>';
        return;
    }

    shows.forEach(item => {
        const card = document.createElement('div');
        card.className = 'show-card';
        card.setAttribute('data-show-id', item.show.id); // Save ID for fetching details
        card.style.cursor = 'pointer'; // Indicate it's clickable

        const imageUrl = item.show.image ? item.show.image.medium : 'https://via.placeholder.com/210x295?text=No+Image';
        card.innerHTML = `
            <h3>${item.show.name}</h3>
            <img src="${imageUrl}" alt="Poster for ${item.show.name}" />
            <p class="show-description">${item.show.summary ? item.show.summary : 'No description available.'}</p>
            <button onclick="addToFavourites('${item.show.name}', ${item.show.id})">Add to Favourites</button>
        `;

        card.addEventListener('click', function (event) {
            if (event.target.tagName.toLowerCase() !== 'button') { // Prevent triggering when clicking "Add to Favourites"
                showDetails(item.show.id);
            }
        });

        results.appendChild(card);
    });
}

// Fetch and show detailed view of a show
async function showDetails(showId) {
    console.log("Fetching show details for ID:", showId);
    loading.style.display = 'block';
    try {
        const res = await fetch(`https://api.tvmaze.com/shows/${showId}`);
        const show = await res.json();
        loading.style.display = 'none';
        console.log("Detailed show info:", show);

        results.innerHTML = `
            <div class="show-card">
                <h2>${show.name}</h2>
                <img src="${show.image ? show.image.medium : 'https://via.placeholder.com/210x295?text=No+Image'}" alt="Poster for ${show.name}" />
                <p>${show.summary ? show.summary : 'No description available.'}</p>
                <p><strong>Language:</strong> ${show.language}</p>
                <p><strong>Premiered:</strong> ${show.premiered}</p>
                <p><strong>Rating:</strong> ${show.rating.average ? show.rating.average : 'N/A'}</p>
                <a href="${show.officialSite || '#'}" target="_blank" rel="noopener">Visit Official Site</a><br><br>
                <button onclick="showSection('search')">Back to Search</button>
            </div>
        `;
    } catch (error) {
        loading.style.display = 'none';
        console.error("Error fetching show details:", error);
        results.innerHTML = '<p>Could not load show details. Please try again later.</p>';
    }
}

// Add to favourites with ID
function addToFavourites(name, id) {
    console.log("Adding to favourites:", name, id);
    const favourite = { name, id };
    if (!favourites.some(fav => fav.name === name)) {
        favourites.push(favourite);
        localStorage.setItem('favourites', JSON.stringify(favourites));
        console.log("Updated favourites list:", favourites);
        displayFavourites();

        const notification = document.createElement('div');
        notification.className = 'favourites-notification';
        notification.textContent = `${name} has been added to your favourites!`;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    } else {
        console.log(`${name} is already in favourites.`);
    }
}

// Display favourites (clickable)
function displayFavourites() {
    console.log("Displaying favourites...");
    favouritesContainer.innerHTML = '';
    if (favourites.length === 0) {
        favouritesContainer.innerHTML = '<p>No favourites added yet.</p>';
        return;
    }

    favourites.forEach(fav => {
        const item = document.createElement('div');
        item.className = 'show-card';
        item.style.cursor = 'pointer';
        item.innerHTML = `
            <h3>${fav.name}</h3>
            <button onclick="removeFromFavourites('${fav.name}')">Remove</button>
        `;
        item.addEventListener('click', function (event) {
            if (event.target.tagName.toLowerCase() !== 'button') { // Prevent remove button click
                showDetails(fav.id);
            }
        });
        favouritesContainer.appendChild(item);
    });
}

// Update history display (clickable)
function updateHistory() {
    console.log("Updating history list on page...");
    historyList.innerHTML = '';
    history.forEach(term => {
        const li = document.createElement('li');
        li.className = 'history-item';
        li.textContent = term;
        li.style.cursor = 'pointer';
        li.addEventListener('click', () => {
            input.value = term;
            form.dispatchEvent(new Event('submit')); // Trigger search
        });
        historyList.appendChild(li);
    });
}
