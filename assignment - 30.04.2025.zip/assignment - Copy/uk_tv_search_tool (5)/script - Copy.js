const form = document.getElementById('search-form');
const input = document.getElementById('search-input');
const results = document.getElementById('results');
const favouritesContainer = document.getElementById('favourites');
const historyList = document.getElementById('search-history');
const loading = document.getElementById('loading');

let favourites = JSON.parse(localStorage.getItem('favourites')) || [];
let history = JSON.parse(localStorage.getItem('history')) || [];

console.log("Page loaded. Favourites:", favourites);
console.log("Page loaded. Search history:", history);

// Handle form submission
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    console.log("Form submitted.");

    const query = input.value.trim();
    console.log("Search query:", query);

    if (!query) {
        console.warn("Empty search query submitted.");
        return;
    }

    addToHistory(query);
    loading.style.display = 'block';
    console.log("Loading spinner shown.");

    try {
        console.log("Fetching data from TVMaze API...");
        const res = await fetch(`https://api.tvmaze.com/search/shows?q=${query}`);
        const data = await res.json();
        console.log("API response received:", data);

        loading.style.display = 'none';
        console.log("Loading spinner hidden.");

        const ukShows = data.filter(item =>
            item.show.network && item.show.network.country.code === 'GB'
        );
        console.log("Filtered UK shows:", ukShows);

        displayResults(ukShows);
    } catch (error) {
        loading.style.display = 'none';
        console.error("Error fetching data:", error);
        results.innerHTML = '<p>Something went wrong. Please try again later.</p>';
    }
});

// Display results
function displayResults(shows) {
    console.log("Displaying results...");
    results.innerHTML = '';
    if (shows.length === 0) {
        results.innerHTML = '<p>No UK shows found.</p>';
        return;
    }

    shows.forEach(item => {
        const card = document.createElement('div');
        card.className = 'show-card';

        const imageUrl = item.show.image ? item.show.image.medium : 'https://via.placeholder.com/210x295?text=No+Image';
        console.log(`Image URL for ${item.show.name}:`, imageUrl);

        card.innerHTML = `
            <h3>${item.show.name}</h3>
            <img src="${imageUrl}" alt="Poster for ${item.show.name}" />
            <p class="show-description">${item.show.summary ? item.show.summary : 'No description available.'}</p>
            <button onclick="addToFavourites('${item.show.name}')">Add to Favourites</button>
        `;

        results.appendChild(card);
    });
}

// Add to favourites
function addToFavourites(show) {
    console.log("Adding to favourites:", show);
    if (!favourites.includes(show)) {
        favourites.push(show);
        localStorage.setItem('favourites', JSON.stringify(favourites));
        console.log("Updated favourites list:", favourites);
        displayFavourites();

        const notification = document.createElement('div');
        notification.className = 'favourites-notification';
        notification.textContent = `${show} has been added to your favourites!`;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    } else {
        console.log(`${show} is already in favourites.`);
    }
}

// Remove from favourites
function removeFromFavourites(show) {
    console.log("Removing from favourites:", show);
    favourites = favourites.filter(fav => fav !== show);
    localStorage.setItem('favourites', JSON.stringify(favourites));
    console.log("Updated favourites list after removal:", favourites);
    displayFavourites();
}

// Display favourites
function displayFavourites() {
    console.log("Displaying favourites...");
    favouritesContainer.innerHTML = '';
    if (favourites.length === 0) {
        favouritesContainer.innerHTML = '<p>No favourites added yet.</p>';
        return;
    }

    favourites.forEach(show => {
        const item = document.createElement('div');
        item.className = 'show-card';
        item.innerHTML = `
            <p>${show}</p>
            <button onclick="removeFromFavourites('${show}')">Remove</button>
        `;
        favouritesContainer.appendChild(item);
    });
}

// Add to history
function addToHistory(query) {
    console.log("Adding to search history:", query);
    if (!history.includes(query)) {
        history.push(query);
        localStorage.setItem('history', JSON.stringify(history));
        console.log("Updated history:", history);
        updateHistory();
    }
}

// Update history display
function updateHistory() {
    console.log("Updating history list on page...");
    historyList.innerHTML = '';
    history.forEach(term => {
        const li = document.createElement('li');
        li.textContent = term;
        historyList.appendChild(li);
    });
}

// Clear history
function clearHistory() {
    console.log("Clearing search history...");
    localStorage.removeItem('history');
    history = [];
    updateHistory();
    console.log("Search history cleared.");
}

// Show section
function showSection(section) {
    console.log(`Showing section: ${section}`);
    document.getElementById('search-section').style.display = section === 'search' ? 'block' : 'none';
    document.getElementById('favourites-section').style.display = section === 'favourites' ? 'block' : 'none';
    document.getElementById('history-section').style.display = section === 'history' ? 'block' : 'none';

    if (section === 'favourites') displayFavourites();
    if (section === 'history') updateHistory();

    updateActiveNav(section);
}

// Update navigation highlight
function updateActiveNav(section) {
    console.log(`Updating active nav to: ${section}`);
    const navButtons = {
        search: document.getElementById('nav-home'),
        favourites: document.getElementById('nav-favourites'),
        history: document.getElementById('nav-history')
    };

    Object.values(navButtons).forEach(button => button.classList.remove('active'));
    if (navButtons[section]) navButtons[section].classList.add('active');
}

// Toggle contrast mode
function toggleContrast() {
    console.log("Toggling high contrast mode.");
    document.body.classList.toggle('high-contrast');
}

// Toggle dark mode
function toggleDarkMode() {
    console.log("Toggling dark mode.");
    document.body.classList.toggle('dark-mode');
}
